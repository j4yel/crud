-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2019 at 09:48 AM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_account`
--
CREATE DATABASE IF NOT EXISTS `user_account` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `user_account`;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_name` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `age` int(90) NOT NULL,
  `email` varchar(90) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_name`, `first_name`, `last_name`, `created_at`, `age`, `email`, `password`, `id`) VALUES
('jestacio', 'jonathan', 'estacio', '2019-08-22 04:39:23', 0, '', '', 1),
('ddoloso', 'dobert', 'deloso', '2019-08-22 04:39:23', 0, '', '', 2),
('mmondoy', 'mariela', 'mondoy', '2019-08-22 04:40:37', 0, '', '', 3),
('jjlagumbay', 'jonel', 'lagumbay', '2019-08-23 05:42:53', 0, '', '', 4),
('robert', 'robert', 'selbor', '2019-08-23 05:55:18', 0, '', '', 5),
('pogi', 'lolo', 'ko', '2019-08-23 06:07:49', 21, 'pogi@gmail.com', 'password', 6),
('eric', 'eric', 'delion', '2019-08-23 06:34:17', 0, '', '', 7),
('admin', 'admin', 'admin', '2019-08-23 07:32:45', 21, 'admin@gmail.com', 'admin', 8),
('excel', 'excel', 'technical', '2019-08-23 07:43:29', 22, 'excel@gmail.com', 'excel', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
